const carouselImages = document.querySelector('.carousel-images');
const items = document.querySelectorAll('.carousel-item');
const prevButton = document.getElementById('prev');
const nextButton = document.getElementById('next');
const captionContainer = document.querySelector('.carousel-caption-container .carousel-caption');

const captions = [
    "Лучшие медицинские услуги",
    "Современное оборудование",
    "Квалифицированные специалисты"
];

let index = 0;

// Обновляем отображение изображений и текста
function updateCarousel() {
    carouselImages.style.transform = `translateX(${-index * 100}%)`;
    captionContainer.textContent = captions[index];
}

// Переключение на следующий слайд
nextButton.addEventListener('click', () => {
    index = (index + 1) % items.length;
    updateCarousel();
});

// Переключение на предыдущий слайд
prevButton.addEventListener('click', () => {
    index = (index - 1 + items.length) % items.length;
    updateCarousel();
});

// Автоматическое пролистывание
setInterval(() => {
    index = (index + 1) % items.length;
    updateCarousel();
}, 5000);

// Обновляем при изменении размера окна
window.addEventListener('resize', updateCarousel);

// Первоначальный вызов
updateCarousel();
