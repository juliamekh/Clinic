var Cal = function(divId) {
    this.divId = divId;
    this.DaysOfWeek = ['Пн', 'Вт', 'Ср', 'Чтв', 'Птн', 'Суб', 'Вск'];
    this.Months = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];

    var d = new Date();
    this.currMonth = d.getMonth();
    this.currYear = d.getFullYear();
    this.currDay = d.getDate();
};

Cal.prototype.nextMonth = function() {
    if (this.currMonth === 11) {
        this.currMonth = 0;
        this.currYear += 1;
    } else {
        this.currMonth += 1;
    }
    this.showcurr();
};

Cal.prototype.previousMonth = function() {
    if (this.currMonth === 0) {
        this.currMonth = 11;
        this.currYear -= 1;
    } else {
        this.currMonth -= 1;
    }
    this.showcurr();
};

Cal.prototype.showcurr = function() {
    this.showMonth(this.currYear, this.currMonth);
};

Cal.prototype.showMonth = function(y, m) {
    const firstDayOfMonth = new Date(y, m, 1).getDay();
    const lastDateOfMonth = new Date(y, m + 1, 0).getDate();

    let html = '<table>';
    html += `<thead><tr><td colspan="7">${this.Months[m]} ${y}</td></tr></thead>`;
    html += '<tr class="days">';

    // Заголовки дней
    for (let i = 0; i < this.DaysOfWeek.length; i++) {
        html += `<td>${this.DaysOfWeek[i]}</td>`;
    }
    html += '</tr>';

    let dateCount = 1;
    for (let row = 0; row < 5; row++) {
        html += '<tr>';
        for (let col = 0; col < 7; col++) {
            if ((row * 7 + col) < firstDayOfMonth || dateCount > lastDateOfMonth) {
                html += `<td class="not-current">${dateCount}</td>`;
            } else {
                if (dateCount === new Date().getDate()) {
                    html += `<td class="today">${dateCount}</td>`;
                } else {
                    html += `<td>${dateCount}</td>`;
                }
            }
            dateCount++;
        }
        html += '</tr>';
    }

    html += '</table>';
    document.getElementById(this.divId).innerHTML = html;
};

window.onload = function() {
    var c = new Cal("divCal");
    c.showcurr();

    document.getElementById('btnNext').onclick = function() {
        c.nextMonth();
    };

    document.getElementById('btnPrev').onclick = function() {
        c.previousMonth();
    };
};
