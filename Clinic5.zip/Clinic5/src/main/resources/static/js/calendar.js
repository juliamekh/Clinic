async function fetchDoctorCalendar(doctorId) {
    try {
        const response = await fetch(`/doctor/calendar/${doctorId}`);
        if (!response.ok) {
            throw new Error('Ошибка при загрузке данных');
        }

        const data = await response.json();
        renderCalendar(data);
    } catch (error) {
        document.getElementById('loading').innerText = 'Ошибка: ' + error.message;
    }
}

function renderCalendar(data) {
    const tableBody = document.querySelector('#calendarTable tbody');
    tableBody.innerHTML = ''; // Очищаем таблицу перед добавлением данных

    if (data.length === 0) {
        document.getElementById('loading').innerText = 'Данных не найдено';
        return;
    }

    data.forEach(item => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${new Date(item.calendarDate).toLocaleDateString()}</td>
            <td>${item.startTime}</td>
            <td>${item.endTime}</td>
            <td>${item.note || 'Нет примечаний'}</td>
        `;
        tableBody.appendChild(row);
    });

    document.getElementById('loading').style.display = 'none';
}

// Извлекаем ID из URL и передаем его
document.addEventListener('DOMContentLoaded', function() {
    const doctorId = window.location.pathname.split('/').pop();
    fetchDoctorCalendar(doctorId);
});
