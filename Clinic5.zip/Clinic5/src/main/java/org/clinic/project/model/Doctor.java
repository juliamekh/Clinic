package org.clinic.project.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "doctor")
public class Doctor {
    
    @Id
    @NotBlank(message = "Требуется ввести ID.")
    @Pattern(regexp = "^[a-zA-Z0-9]{4}$", message = "Должно быть ровно 4 символа")
    @Column(nullable = false, length = 10)
    private String doctorID;

    @Column(nullable = false, length = 64, name = "password")
    private String password;
    
    @Transient
    @Pattern(regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{8,20}$", message = "Должен содержать 1 заглавный, 1 строчный, 1 цифру и содержать от 8 до 20 символов")
    private String plainPassword;

    @NotBlank(message = "Требуется ввести имя.")
    @Size(max = 25, message = "Имя должно быть максимум 25 символов.")
    @Column(nullable = false, length = 25, name = "first_name")
    private String firstName;

    @NotBlank(message = "Требуется ввести фамилию.")
    @Size(max = 25, message = "Фамилия должно быть максимум 25 символов.")
    @Column(nullable = false, length = 25, name = "last_name")
    private String lastName;

    @NotBlank(message = "Требуется ввести email.")
    @Email(message = "Введите корректный адрес email")
    @Column(nullable = false, length = 50, name = "email")
    private String email;

    @Column(nullable = false, name = "date_of_birth")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date dob;

    @NotBlank(message = "Требуется ввести пол.")
    @Size(max = 6)
    @Column(nullable = false, length = 6, name = "sex")
    private String sex;

    public String getDoctorID() {
        return doctorID;
    }

    public void setDoctorID(String doctorID) {
        this.doctorID = doctorID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPlainPassword() {
		return plainPassword;
	}

	public void setPlainPassword(String plainPassword) {
		this.plainPassword = plainPassword;
	}

	public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    @Override
    public String toString() {
        return doctorID;
    }
    
}