package org.clinic.project.calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorCalendarService {

    @Autowired
    private DoctorCalendarRepository calendarRepository;

    /**
     * Возвращаем записи по doctorId
     */
    public List<DoctorCalendar> getDoctorCalendarById(String doctorId) {
        return calendarRepository.findByDoctorId(doctorId);
    }
}
