package org.clinic.project.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

	/*-------------------------- HOMEPAGE  --------------------------*/
	@GetMapping("/account_index")
	public String viewHomePageSignedOut(Model model) {
		model.addAttribute("pageTitle", "Home");
		return "account_index";
	}

	@GetMapping("/")
	public String viewHomePage(Model model) {
		model.addAttribute("pageTitle", "Главная страница");
		return "home/home_page";
	}

	/*-------------------------- Directions  --------------------------*/
	@GetMapping("/home/directions")
	public String viewDirectionsPage(Model model) {
		model.addAttribute("pageTitle", "Направления");
		return "home/directions";
	}

	@GetMapping("/home/departments")
	public String viewDepartmentsPage(Model model) {
		model.addAttribute("pageTitle", "Отделения");
		return "home/departments";
	}

	@GetMapping("/home/specialized_centers")
	public String viewSpecializedCentersPage(Model model) {
		model.addAttribute("pageTitle", "Специализированные центры");
		return "home/specialized_centers";
	}

	/*-------------------------- Doctors  --------------------------*/
	@GetMapping("/home/doctors")
	public String viewDoctorsPage(Model model) {
		model.addAttribute("pageTitle", "Врачи");
		return "home/doctors";
	}

	/*-------------------------- Check Up Info  --------------------------*/
	@GetMapping("/home/check_up_info")
	public String viewCheckUpInfoPage(Model model) {
		model.addAttribute("pageTitle", "Check Up");
		return "home/check_up_info";
	}

	/*-------------------------- Hospitalization  --------------------------*/
	@GetMapping("/home/hospitalization")
	public String viewHospitalizationPage(Model model) {
		model.addAttribute("pageTitle", "Госпитализация");
		return "home/hospitalization";
	}


	/*-------------------------- For Non Residents  --------------------------*/
	@GetMapping("/home/for_nonresident_patients")
	public String viewForNonResidentsPage(Model model) {
		model.addAttribute("pageTitle", "Иногородним пациентам");
		return "home/for_nonresident_patients";
	}

	/*-------------------------- Results of Studies  --------------------------*/
	@GetMapping("/home/results_of_studies")
	public String viewResultsOfStudiesPage(Model model) {
		model.addAttribute("pageTitle", "Результаты анализов");
		return "home/results_of_studies";
	}

	/*-------------------------- Schedule and Rules  --------------------------*/
	@GetMapping("/home/schedule_and_rules")
	public String viewScheduleAndRulesPage(Model model) {
		model.addAttribute("pageTitle", "График и правила посещения пациентов");
		return "home/schedule_and_rules";
	}


	/*-------------------------- Order of the Morgue  --------------------------*/
	@GetMapping("/home/order_of_the_morgue")
	public String viewOrderOfTheMorguePage(Model model) {
		model.addAttribute("pageTitle", "Порядок работы морга");
		return "home/order_of_the_morgue";
	}

	/*-------------------------- Feedbacks  --------------------------*/
	@GetMapping("/home/feedbacks")
	public String viewFeedbacksPage(Model model) {
		model.addAttribute("pageTitle", "Отзывы");
		return "home/feedbacks";
	}

	@GetMapping("/tracker")
	public String getTrackerPage() {
		return "tracker"; // Это имя HTML-шаблона (tracker.html), который вы создадите
	}
}
