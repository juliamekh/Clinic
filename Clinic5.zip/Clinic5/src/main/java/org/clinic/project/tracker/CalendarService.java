package org.clinic.project.tracker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class CalendarService {

    @Autowired
    private EventRepository er;

    @Transactional
    public Event createEvent(Event event) {
        return er.save(event);
    }

    @Transactional
    public Event moveEvent(Long id, LocalDateTime start, LocalDateTime end) {
        Event e = er.findById(id).orElseThrow(() -> new IllegalArgumentException("Event not found"));
        e.setStart(start);
        e.setEnd(end);
        return er.save(e);
    }

    @Transactional
    public Event setColor(Long id, String color) {
        Event e = er.findById(id).orElseThrow(() -> new IllegalArgumentException("Event not found"));
        e.setColor(color);
        return er.save(e);
    }

    @Transactional
    public void deleteEvent(Long id) {
        if (!er.existsById(id)) {
            throw new IllegalArgumentException("Event not found");
        }
        er.deleteById(id);
    }

    public Iterable<Event> findEventsBetween(LocalDateTime start, LocalDateTime end) {
        return er.findBetween(start, end);
    }
}
