package org.clinic.project.calendar;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DoctorCalendarRepository extends JpaRepository<DoctorCalendar, Integer> {

    List<DoctorCalendar> findByDoctorId(String doctorId);
}

